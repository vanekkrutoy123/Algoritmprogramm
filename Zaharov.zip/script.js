// alert( 'привет мир!!!');




// let message;
// message = 'hello world!!';  ///////////////    Let переменая для обозначения  слов и цыфр
// alert(message);
 



// let user = 'шнее пепе';
// age = '17';
// alert(user);
// alert(age);



 // console.log(1+4+3+6)

//  let user = {   
// name: "Daniil",
// age: "17"
//  };
//  alert( user.name );
//  alert( user.age );


// delete user.age;

// const user = {
//   name: "Daniil"
// };

// user.name = "Pete"; 

// alert(user.name);


/*
        let x=10;
        let y=5;
        // let z="first";
        // let x="second";
        console.log(x+y);
        console.log(x-y);
        console.log(x*y);
        console.log(x/y);
        console.log(x**y);
        console.log(x%y);
15
-5 
50 
0.5 
9765625 
5
*/

// let age = Number(prompt("Введите свой возраст:"));
// alert("Ваш возраст через 10 лет: " + (age+10));


// let age = prompt("Enter ur age")
// age=Number(age);
// let newAge=age+10;
// alert("ur age in 10 years" + (newAge))


// let x=Number(prompt())
// let x=+prompt()
// if(x>5){
//     console.log ("x bolshe 5")}
// else if (x===5) {
//     console.log ("x raven 5")
// }
// else {
//     console.log("x menshe 5")
// }
// let x=+prompt()
// let message =(x>5)?"x больше 5": "x меньше или равен 5"
// console.log(message)



let x=true
let y=false
console.log((x&&!y)||(!x&&y))